<?php
require "GenererCle.pph";

$genererCle = new GenererCle();
$genererCle->faire_permutation();

?>